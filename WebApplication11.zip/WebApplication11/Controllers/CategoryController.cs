﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication11.Models;
using WebApplication11.Repository;

namespace WebApplication11.Controllers
{
    public class CategoryController : Controller
    {
        public ActionResult GetAllProductDetails()
        {

            Categoryrepo categoryrepo = new Categoryrepo();
            ModelState.Clear();
            return View(categoryrepo.GetAllCategories());
        }
        public ActionResult AddCategory()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddCategory(CategoryModel obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Categoryrepo categoryrepo = new Categoryrepo();

                    if (categoryrepo.AddCategory(obj))
                    {
                        ViewBag.Message = "Category details added successfully";
                    }
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/EditEmpDetails/5    
        public ActionResult EditCategoryDetails(int CategoryId)
        {
            Categoryrepo categoryrepo = new Categoryrepo();

            return View(categoryrepo.GetAllCategories().Find(obj => obj.CategoryId == CategoryId));

            

        }

        // POST: Employee/EditEmpDetails/5    
        [HttpPost]

        public ActionResult EditCategoryDetails(int CategoryId, CategoryModel obj)
        {
            try
            {
                Categoryrepo categoryrepo = new Categoryrepo();

                categoryrepo.UpdateCategory(obj);
                return RedirectToAction("GetAllEmpDetails");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/DeleteEmp/5    
        public ActionResult DeleteEmp(int CategoryId)
        {
            try
            {
                Categoryrepo categoryrepo = new Categoryrepo();


                if (categoryrepo.Deletecategory(CategoryId))
                {
                    ViewBag.AlertMsg = "category details deleted successfully";

                }
                return RedirectToAction("GetAllEmpDetails");

            }
            catch
            {
                return View();
            }
        }

    }
}
