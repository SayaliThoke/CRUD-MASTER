﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication11.Models;
using WebApplication11.Repository;

namespace WebApplication11.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult GetAllProductDetails()
        {

            Productrepo productrepo = new Productrepo();
            ModelState.Clear();
            return View(productrepo.GetAllProducts());
        }
        public ActionResult Addproduct()
        {
            return View();
        }

         [HttpPost]
        public ActionResult Addproduct(ProductModel obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Productrepo productrepo = new Productrepo();

                    if (productrepo.AddProduct(obj))
                    {
                        ViewBag.Message = "Product details added successfully";
                    }
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

        public ActionResult EditProductDetails(int ProductId)
        {
            Productrepo productrepo = new Productrepo();
            return View(productrepo.GetAllProducts().Find(obj => obj.ProductId == ProductId));



        }

        [HttpPost]

        public ActionResult EditProducctDetails(int ProductId, ProductModel obj)
        {
            try
            {
                Productrepo productrepo = new Productrepo();

                productrepo.UpdateProduct(obj);
                return RedirectToAction("GetAllProductDetails");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult DeleteProduct(int ProductId)
        {
            try
            {
                Productrepo productrepo = new Productrepo();


                if (productrepo.DeleteProduct(ProductId))
                {
                    ViewBag.AlertMsg = "Product details deleted successfully";

                }
                return RedirectToAction("GetAllEmpDetails");

            }
            catch
            {
                return View();
            }
        }


    }
}
