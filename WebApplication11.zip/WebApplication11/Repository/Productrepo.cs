﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WebApplication11.Models;

namespace WebApplication11.Repository
{
    public class Productrepo
    {

        private SqlConnection con;
        //To Handle connection related activities    
        private void connection()
        {
            string constr = ConfigurationManager.ConnectionStrings["getconn"].ToString();
            con = new SqlConnection(constr);

        }
        //To Add Employee details    
        public bool AddProduct(ProductModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("Insert into Product values(@ProductId,@ProductName,@CategoryId,@CategoryName)", con);
            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@ProductId", obj.ProductId);
            com.Parameters.AddWithValue("@ProductName", obj.ProductName);
            com.Parameters.AddWithValue("@CategoryId", obj.CategoryId);
            com.Parameters.AddWithValue("@CategoryName", obj.CategoryName);


            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;

            }
            else
            {

                return false;
            }


        }
        public List<ProductModel> GetAllProducts()
        {
            connection();
            List<ProductModel> Productlist = new List<ProductModel>();


            SqlCommand com = new SqlCommand("select * from Product", con);
            com.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();

            con.Open();
            da.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {

                Productlist.Add(

                    new ProductModel
                    {

                        ProductId = Convert.ToInt32(dr["ProductId"]),
                        ProductName = Convert.ToString(dr["ProductName"]),
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"]),


                    }
                    );
            }

            return Productlist;
        }
        public bool UpdateProduct(ProductModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("Update Product set ProductId = @ProductId,ProductName=@ProductName,CategoryId=@CategoryId,CategoryName=@CategoryName where ProductId= @ProductId  ", con);

            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@ProductId", obj.ProductId);

            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;
            }
            else
            {
                return false;
            }
        }
        //To delete Employee details    
        public bool DeleteProduct(int ProductId)
        {

            connection();
            SqlCommand com = new SqlCommand("Delete from Product where ProductId=@ProductId  ", con);

            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@ProductId", ProductId);

            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }
    }
}