﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WebApplication11.Models;

namespace WebApplication11.Repository
{
    public class Categoryrepo
    {

        private SqlConnection con;
        //To Handle connection related activities    
        private void connection()
        {
            string constr = ConfigurationManager.ConnectionStrings["getconn"].ToString();
            con = new SqlConnection(constr);

        }
        //To Add Employee details    
        public bool AddCategory(CategoryModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("Insert into Category values(@categoryid,@Categoryname)", con);
            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@categoryid", obj.CategoryId);
            com.Parameters.AddWithValue("@Categoryname", obj.CategoryName);
            

            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;

            }
            else
            {

                return false;
            }


        }
        //To view employee details with generic list     
        public List<CategoryModel> GetAllCategories()
        {
            connection();
            List<CategoryModel> categorylist = new List<CategoryModel>();


            SqlCommand com = new SqlCommand("select * from Category", con);
            com.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();

            con.Open();
            da.Fill(dt);
            con.Close();
            //Bind EmpModel generic list using dataRow     
            foreach (DataRow dr in dt.Rows)
            {

                categorylist.Add(

                    new CategoryModel
                    {

                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"]),
                        

                    }
                    );
            }

            return categorylist;
        }
        //To Update Employee details    
        public bool UpdateCategory(CategoryModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("Update Category set CategoryName = @CategoryName where CategoryId= @CategoryId  ", con);

            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@CategoryId", obj.CategoryId);
  
            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;
            }
            else
            {
                return false;
            }
        }
        //To delete Employee details    
        public bool Deletecategory(int CategoryId)
        {

            connection();
            SqlCommand com = new SqlCommand("Delete from Category where CategoryId=@CategoryId  ", con);

            com.CommandType = CommandType.Text;
            com.Parameters.AddWithValue("@CategoryId", CategoryId);

            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

    }
}